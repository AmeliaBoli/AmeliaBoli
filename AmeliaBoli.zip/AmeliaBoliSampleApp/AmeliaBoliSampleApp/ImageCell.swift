//
//  ImageCell.swift
//  AmeliaBoliSampleApp
//
//  Created by Amelia Boli on 4/19/15.
//  Copyright (c) 2015 AmeliaBoli. All rights reserved.
//

import UIKit

class ImageCell: UICollectionViewCell {
    
    @IBOutlet weak var imageOnlyCell: UIImageView!
}
